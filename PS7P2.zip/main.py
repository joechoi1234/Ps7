
def totalbatavg(hits, bats):
  batavg = float(bats) / float(hits)

  return batavg
                      
            
lastname = input("Enter last name: ")
bats = float(input("Enter number of times at bat: "))
hits = float(input("Enter number of hits: "))

batavg = totalbatavg(hits, bats)

print("Batting average: " , batavg)
print("Last name: " , lastname)