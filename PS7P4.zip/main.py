

def compgrosspay(jobcode, hours):
  grosspay = float(payrate) * float(hours)
  return grosspay

lastname = input("Enter last name: ")
jobcode = input("Enter job code(L / A / J): ")
hours = float(input("Enter hours worked: "))





if jobcode == "L":
  payrate = 25.00
elif jobcode == "A":
  payrate = 30.00
else:
  payrate = 50.00

grosspay = compgrosspay(jobcode, hours)
if hours > 40:
  grosspay = (40 * payrate) + ((hours - 40) * (payrate * 1.5))


print("Last name: " , lastname)
print("Gross pay: $" , grosspay)

