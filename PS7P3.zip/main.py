
def compmpg(miles, gallons):
  mpg = float(miles) / float(gallons)

  return mpg

city = input("Enter destination city: ")
miles = float(input("Enter miles travelled: "))
gallons = float(input("Enter gallon amount: "))
price = 2.5

def compcost(gallons, price):
  cost = float(gallons) * float(price)

  return cost

mpg = compmpg(miles, gallons)
cost = compcost(gallons, price)

print("Miles per gallon: " , mpg)
print("Gas cost: " , cost)
print("City: " , city)
