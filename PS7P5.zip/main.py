
def comptuition(distcode, hours):
  tuition = float(payrate) * float(hours)

  return tuition

lastname = input("Enter last name: ")
hours = float(input("Enter credit hours: "))
distcode = input("Enter district code(I or O): ")

if distcode == "I":
  payrate = 250.00
else:
  payrate = 550.00

tuition = comptuition(distcode, hours)


print("Last name: " , lastname)
print("Tuition owed: " , tuition)